---
name: Issue submission
about: If you are experiencing issues with the module, please follow this procedure.
title: ''
labels: ''
assignees: ''

---

If there are issues with the module, start with checking out the [common issues](https://github.com/Magisk-Modules-Repo/MagiskHide-Props-Config/blob/master/README.md#issues-support-etc) section in the docs.

And, if you do submit an issue ticket do not forget to include [logs](https://github.com/Magisk-Modules-Repo/MagiskHide-Props-Config/blob/master/README.md#logs).
